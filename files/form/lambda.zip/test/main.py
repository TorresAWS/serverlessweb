import json
import variables

print(variables.email)
